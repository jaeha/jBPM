package com.jtech.jbpm;

import android.content.Context;
import android.database.Cursor;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BPadapter extends CursorAdapter {
    public BPadapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item_bp, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView tvSYS = (TextView) view.findViewById(R.id.tvSYS);
        TextView tvDIA = (TextView) view.findViewById(R.id.tvDIA);
        TextView tvPulse = (TextView) view.findViewById(R.id.tvPulse);
        TextView tvWeight = (TextView) view.findViewById(R.id.tvWeight);
        TextView tvDate =  (TextView) view.findViewById(R.id.tvDate);

        tvSYS.setText(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow("sys"))));
        tvDIA.setText(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow("dia"))));
        tvPulse.setText(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow("pulse"))));
        tvWeight.setText(String.valueOf(cursor.getDouble(cursor.getColumnIndexOrThrow("weight"))));
        Date enterdate = Util.db2date(cursor.getString(cursor.getColumnIndexOrThrow("enterdate")));
        tvDate.setText(Util.date2short(enterdate));
    }
}
