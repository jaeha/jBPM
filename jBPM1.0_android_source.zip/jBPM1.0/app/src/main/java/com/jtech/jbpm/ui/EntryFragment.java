package com.jtech.jbpm.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.jtech.jbpm.BP;
import com.jtech.jbpm.JDB;
import com.jtech.jbpm.R;

public class EntryFragment extends Fragment {

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_entry, container, false);
        final Button saveButton = (Button) root.findViewById(R.id.btSave);
        final TextView tvSYS = root.findViewById(R.id.tvSYS);
        final TextView tvDIA = root.findViewById(R.id.tvDIA);
        final TextView tvPulse = root.findViewById(R.id.tvPulse);
        final TextView tvWeight = root.findViewById(R.id.tvWeight);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final TextView tvSaveMessage = root.findViewById(R.id.tvSaveMessage);
                JDB db = JDB.getInstance(root.getContext());
                BP bp = new BP();
                bp.setSys(Integer.parseInt(tvSYS.getText().toString()));
                bp.setDia(Integer.parseInt(tvDIA.getText().toString()));
                bp.setPulse(Integer.parseInt(tvPulse.getText().toString()));
                bp.setWeight(Double.parseDouble(tvWeight.getText().toString()));
                if (bp.isValid()) {
                    db.addBP(bp);
                    tvSaveMessage.setText("Saved Successfully!");
                 //   Toast.makeText(root.getContext(), "Saved successfully!", Toast.LENGTH_LONG).show();
                    saveButton.setEnabled(false);
                } else {
                    tvSaveMessage.setText("Invalid inputs!");
                }

            }
        });

        //  dashboardViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
     /*   @Override
        public void onChanged(@Nullable String s) {
            //           textView.setText(s);
        }
    });
      */  return root;
}
}
