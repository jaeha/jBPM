package com.jtech.jbpm;

import java.util.HashMap;

public final class GP {
    private static double appVersion = 1;
    private static String dbName = "jbpm";
    private static int dbVersion = 1;
    private static int chartMaxRecords = 90;

    public static double getAppVersion() {
        return appVersion;
    }

    public static void setAppVersion(double appVersion) {
        GP.appVersion = appVersion;
    }

    public static String getDbName() {
        return dbName;
    }

    public static void setDbName(String dbName) {
        GP.dbName = dbName;
    }

    public static int getDbVersion() {
        return dbVersion;
    }

    public static void setDbVersion(int dbVersion) {
        GP.dbVersion = dbVersion;
    }

    public static int getChartMaxRecords() {
        return chartMaxRecords;
    }

    public static void setChartMaxRecords(int chartMaxRecords) {
        GP.chartMaxRecords = chartMaxRecords;
    }

    public static boolean isValid() {
        if (GP.chartMaxRecords<1) {
            return false;
        }
        else {
            return true;
        }
    }
}
