package com.jtech.jbpm.ui;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.jtech.jbpm.BP;
import com.jtech.jbpm.GP;
import com.jtech.jbpm.JDB;
import com.jtech.jbpm.R;

public class SettingsFragment extends Fragment {

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        JDB db = JDB.getInstance(getContext());
        db.loadSettings();

        View root = inflater.inflate(R.layout.fragment_settings, container, false);
        final TextView tvSysInfo = root.findViewById(R.id.tvSysInfo);
        final TextView tvChartMaxRecords = root.findViewById(R.id.tvChartMaxRecords);
        final Button saveButton = (Button) root.findViewById(R.id.btSave);
        final Button removeDataButton = (Button) root.findViewById(R.id.btRemoveData);

        String dbpath = getContext().getDatabasePath(GP.getDbName()).getPath();

        String infos = String.format("- App Version: v%.2f\n- Data file: %s\n", GP.getAppVersion(), dbpath);
        tvSysInfo.setText(infos);

        tvChartMaxRecords.setText(String.valueOf(GP.getChartMaxRecords()));

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final TextView tvSaveMessage = root.findViewById(R.id.tvSaveMessage);
                GP.setChartMaxRecords(Integer.parseInt(tvChartMaxRecords.getText().toString()));

                if (GP.isValid()) {
                    db.saveSettings();
                    tvSaveMessage.setText("Saved Successfully!");
                    //   Toast.makeText(root.getContext(), "Saved successfully!", Toast.LENGTH_LONG).show();
                    saveButton.setEnabled(false);
                } else {
                    tvSaveMessage.setText("Invalid inputs!");
                }
            }
        });

        removeDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final TextView tvSaveMessage = root.findViewById(R.id.tvRemoveDataMessage);
                final int numRemoved = db.removeAllData();
                tvSaveMessage.setText(numRemoved + " removed Successfully!");
                removeDataButton.setEnabled(false);
            }
        });

        return root;
    }
}