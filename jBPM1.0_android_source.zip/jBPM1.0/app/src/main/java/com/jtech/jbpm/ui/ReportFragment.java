package com.jtech.jbpm.ui;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.jtech.jbpm.BP;
import com.jtech.jbpm.BPadapter;
import com.jtech.jbpm.GP;
import com.jtech.jbpm.JDB;
import com.jtech.jbpm.R;

import java.util.ArrayList;
import java.util.List;

public class ReportFragment extends Fragment {

  //  private ReportViewModel reportViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        Log.d("ReportFragment", "start..");

        View root = inflater.inflate(R.layout.fragment_report, container, false);

        // List
        JDB db = JDB.getInstance(getContext());
        Cursor cursor;
        cursor = db.getCursorBP();
        if (cursor.getCount() <= 0)
                return null;
        BPadapter adapter = new BPadapter(root.getContext(), cursor);
        ListView listView = (ListView) root.findViewById(R.id.lvReportList);
        listView.setAdapter(adapter);

        // Chart
        LineChart chart = root.findViewById(R.id.chartBPLine);

        List<BP> bps = db.getBPs(GP.getChartMaxRecords());
        ArrayList<Entry> vSys = new ArrayList<>();
        ArrayList<Entry> vDia = new ArrayList<>();
        ArrayList<Entry> vPulse = new ArrayList<>();
        ArrayList<Entry> vWeight = new ArrayList<>();

        int j=0;
        for (int i = bps.size()-1; i >= 0 ; i--) {
            vSys.add(new Entry(j, bps.get(i).getSys()));
            vDia.add(new Entry(j, bps.get(i).getDia()));
            vPulse.add(new Entry(j, bps.get(i).getPulse()));
            vWeight.add(new Entry(j, (float)bps.get(i).getWeight()));
            j++;
        }

        LineDataSet sSys = new LineDataSet(vSys, "SYS");
        sSys.setColor(Color.BLUE);
        sSys.setCircleColor(Color.BLUE);

        LineDataSet sDia = new LineDataSet(vDia, "DIA");
        sDia.setColor(Color.YELLOW);
        sDia.setCircleColor(Color.YELLOW);

        LineDataSet sPulse = new LineDataSet(vPulse, "Pulse");
        sPulse.setColor(Color.GREEN);
        sPulse.setCircleColor(Color.GREEN);

        LineDataSet sWeight = new LineDataSet(vWeight, "Weight");
        sWeight.setColor(Color.RED);
        sWeight.setCircleColor(Color.RED);

        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(sSys);
        dataSets.add(sDia);
        dataSets.add(sPulse);
        dataSets.add(sWeight);

        LineData data = new LineData(dataSets);
        chart.setData(data);
        XAxis xAxis = chart.getXAxis();
        xAxis.setLabelCount(bps.size()-1);

        Description desc = chart.getDescription();
        desc.setText("Last " + String.valueOf(bps.size()) + " Records");
        desc.setTextSize(13f);


        return root;
    }
}