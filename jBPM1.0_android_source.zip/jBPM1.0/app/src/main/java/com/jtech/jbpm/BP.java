package com.jtech.jbpm;

import java.util.Calendar;
import java.util.Date;

public class BP {
    private int sys;
    private int dia;
    private int pulse;
    private double weight;
    private Date enterDate;

    public BP() {
        this.setSys(0);
        this.setDia(0);
        this.setPulse(0);
        this.setWeight(0.0);
        this.setEnterDate(Calendar.getInstance().getTime());
    }
    public BP(int sys, int dia, int pulse, double weight, Date enterdate) {
        this.setSys(sys);
        this.setDia(dia);
        this.setPulse(pulse);
        this.setWeight(weight);
        this.setEnterDate(enterdate);
    }

    public boolean isValid() {
        if (this.sys<10 || this.dia<10 || this.pulse<10 || this.weight<10) {
            return false;
        }
        else {
            return true;
        }
    }

    public int getSys() {
        return sys;
    }
    public void setSys(int sys) {
        this.sys = sys;
    }

    public int getDia() {
        return dia;
    }
    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getPulse() {
        return pulse;
    }
    public void setPulse(int pulse) {
        this.pulse = pulse;
    }

    public double getWeight() {
        return weight;
    }
    public void setWeight(double weight) {
        this.weight = weight;
    }

    public Date getEnterDate() {
        return enterDate;
    }
    public void setEnterDate(Date enterDate) { this.enterDate = enterDate; }

}
