package com.jtech.jbpm;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class Util {
    public final static String DATE_FORMAT_DB = "yyyy-MM-dd HH:mm:ss";
    public final static String DATE_FORMAT_SHORT = "MMM dd HH:mm";

    public static Date db2date(String dbstr) {
        SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT_DB);
        Date d = new Date();
        try {
            d = df.parse(dbstr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return d;
    }

    public static String date2db(Date d) {
        SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT_DB);
        return df.format(d);
    }

    public static String date2short(Date d) {
        SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT_SHORT);
        return df.format(d);
    }
}
