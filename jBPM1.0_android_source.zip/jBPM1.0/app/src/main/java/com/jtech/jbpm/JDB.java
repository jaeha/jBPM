package com.jtech.jbpm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.Settings;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class JDB extends SQLiteOpenHelper {
    private static final String DB_NAME = GP.getDbName();
    private static final int DB_VERSION = GP.getDbVersion();
    private static JDB sInstance;
    private static final String TAG = "JDB";

    public static synchronized JDB getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new JDB(context.getApplicationContext());
        }
        return sInstance;
    }

    private  JDB(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_BP_TABLE = "CREATE TABLE bp (_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                "sys INTEGER, dia INTEGER, pulse INTEGER, weight DOUBLE, enterdate DATE)";
        String CREATE_SETTINGS_TABLE = "CREATE TABLE settings (key VARCHAR(128), value VARCHAR(256))";

        db.execSQL(CREATE_BP_TABLE);
        db.execSQL(CREATE_SETTINGS_TABLE);

        // default values
        db.execSQL("INSERT INTO settings VALUES('chartMaxRecords', '90')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "onUpgrade: from " + oldVersion +" to " + newVersion);

        db.execSQL("DROP TABLE IF EXISTS bp ");
        db.execSQL("DROP TABLE IF EXISTS settings");
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "onUpgrade: from " + oldVersion +" to " + newVersion);

        db.execSQL("DROP TABLE IF EXISTS bp ");
        db.execSQL("DROP TABLE IF EXISTS settings");
        onCreate(db);
    }

    public void myUpgrade() {
        SQLiteDatabase db = getWritableDatabase();
       // db.execSQL("CREATE TABLE settings (key VARCHAR(128), value VARCHAR(256))");
       // db.execSQL("INSERT INTO settings VALUES('chartNumberOfRecords', '90')");
      //  db.execSQL("DELETE FROM settings where key='chartNumberOfRecords'");
      //  db.execSQL("INSERT INTO settings VALUES('chartMaxRecords', '90')");

    }

    public void addBP(BP bp) {
        SQLiteDatabase db = getWritableDatabase();

        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("sys", bp.getSys());
            v.put("dia", bp.getDia());
            v.put("pulse", bp.getPulse());
            v.put("weight", bp.getWeight());
            v.put("enterdate", Util.date2db(bp.getEnterDate()));

            db.insertOrThrow("BP", null, v);
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to add data to DB");
        } finally {
            db.endTransaction();
        }
    }

    public Cursor getCursorBP() {
        //String SELECT_QUERY = "SELECT * FROM bp ORDER BY enterdate DESC";
        String SELECT_QUERY = "SELECT * FROM bp ORDER BY enterdate DESC";
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery(SELECT_QUERY, null);
    }

    public List<BP> getBPs(int days) {
        List<BP> bpList = new ArrayList<>();
        String SELECT_QUERY = "SELECT * FROM bp ORDER BY enterdate DESC";

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    BP bp = new BP();
                    bp.setSys(cursor.getInt(cursor.getColumnIndex("sys")));
                    bp.setDia(cursor.getInt(cursor.getColumnIndex("dia")));
                    bp.setPulse(cursor.getInt(cursor.getColumnIndex("pulse")));
                    bp.setWeight(cursor.getDouble(cursor.getColumnIndex("weight")));
                    bp.setEnterDate(Util.db2date(cursor.getString(cursor.getColumnIndex("enterdate"))));
                    bpList.add(bp);
                    if (bpList.size() >= days)
                        break;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d (TAG, "Error while trying to read BP from DB");
        }  finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return bpList;
    }

    public int removeAllData() {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("bp", "1", null);
    }

    public void loadSettings() {
        HashMap<String, String> sMap = new HashMap<String, String>();
        String SELECT_QUERY = "SELECT * FROM settings";

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(SELECT_QUERY, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                sMap.put(cursor.getString(0), cursor.getString(1));
            } while (cursor.moveToNext());
        }
        GP.setChartMaxRecords(Integer.parseInt(sMap.get("chartMaxRecords")));
    }

    public void saveSettings() {
        Log.d (TAG, "Save settings.");
        SQLiteDatabase db = getWritableDatabase();

        ContentValues v = new ContentValues();
        v.put("value", String.valueOf(GP.getChartMaxRecords()));
        db.update("settings", v,"key='chartMaxRecords'", null);
    }
}
